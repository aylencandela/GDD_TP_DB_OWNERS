Curso: K3114

Grupo N° 41

Integrantes:
Valentín, Vallejos - 1765255
Javier, Happel - 1729676
Daniela, Poveda - 1678322
Aylen, Diaz García - 1633107

Email del responsable del grupo: vvallejos@frba.utn.edu.ar